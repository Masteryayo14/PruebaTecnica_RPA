import requests
from bs4 import BeautifulSoup
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine
from app.models import Base, Quote, Tag

URL = "https://quotes.toscrape.com"
engine = create_engine("sqlite:///quotes.db")
Base.metadata.create_all(engine)
Session = sessionmaker(bind=engine)

def scrape():
    session = Session()
    page = 1
    while True:
        res = requests.get(f"{URL}/page/{page}")
        if res.status_code != 200:
            break
        soup = BeautifulSoup(res.text, 'html.parser')
        quotes = soup.select('.quote')
        if not quotes:
            break

        for q in quotes:
            text = q.select_one('.text').text.strip()
            author = q.select_one('.author').text.strip()
            tags = [tag.text.strip() for tag in q.select('.tags .tag')]

            if session.query(Quote).filter_by(text=text).first():
                continue

            quote = Quote(text=text, author=author)
            for tag_name in tags:
                tag = session.query(Tag).filter_by(name=tag_name).first()
                if not tag:
                    tag = Tag(name=tag_name)
                quote.tags.append(tag)

            session.add(quote)
        session.commit()
        page += 1

    session.close()
    print("Scraping completo")
