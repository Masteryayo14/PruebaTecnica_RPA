from flask import Flask, request, jsonify
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models import Quote, Tag

app = Flask(__name__)
engine = create_engine("sqlite:///quotes.db")
Session = sessionmaker(bind=engine)

@app.route("/quotes", methods=["GET"])
def get_quotes():
    session = Session()
    author = request.args.get("author")
    tag = request.args.get("tag")
    search = request.args.get("search")

    query = session.query(Quote)

    if author:
        query = query.filter(Quote.author.ilike(f"%{author}%"))
    if search:
        query = query.filter(Quote.text.ilike(f"%{search}%"))
    if tag:
        query = query.join(Quote.tags).filter(Tag.name.ilike(f"%{tag}%"))

    result = []
    for q in query.all():
        result.append({
            "text": q.text,
            "author": q.author,
            "tags": [t.name for t in q.tags]
        })

    session.close()
    return jsonify(result)
